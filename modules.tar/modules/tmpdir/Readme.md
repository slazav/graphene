## tmpdir

Class for working with temporary directories and zip files.
Create a temporary directory, fill it with files, zip everything,
unzip files to directory etc. Directory and all files
will be deleted in the destructor.

## Changelog

2019.04.30  V.Zavjalov 1.0:
- First version
