## Mapsoft modules

This folder contains modules from mapsoft2 source code library:
https://github.com/slazav/mapsoft2

A make-based building system from mapsoft2 should be used with
these modules. See Makefile.inc